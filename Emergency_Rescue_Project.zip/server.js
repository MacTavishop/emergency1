
const express = require('express');
const twilio = require('twilio');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

const accountSid = 'ACf71f160bd1f6c0c494bb486b751d870d'; // Your Account SID
const authToken = 'bf13f202607e0075e571be50dee9d6a5'; // Your Auth Token
const client = new twilio(accountSid, authToken);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/send-sms', (req, res) => {
    const { name, vehicle, location, emergency } = req.body;

    const message = `🚨 Emergency Rescue Request 🚨\n
Name: ${name}\n
Vehicle: ${vehicle}\n
Location: ${location}\n
Emergency Details: ${emergency}`;

    client.messages
        .create({
            body: message,
            from: '+1XXXXXXXXXX', // Replace with your Twilio phone number
            to: '+916264928523'  // Your Indian number
        })
        .then(message => res.send('Rescue request sent successfully! ✅'))
        .catch(error => {
            console.error(error);
            res.status(500).send('Failed to send SMS. ❌');
        });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
